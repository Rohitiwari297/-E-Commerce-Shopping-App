import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import AddressModalPage from "../AddressModalPage "; // import the AddressModalPage component
import { MdLocationOn } from "react-icons/md";
import { fetchCartAPI, updateCartQuantityAPI } from "../../redux/features/cart/cartSlice";
import CartItem from "./CartItem";

function CartPage() {

  //
  // modal state
  const [openAddressModal, setOpenAddressModal] = useState(false);

  //
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // fetch data from store
  const { items = [], totalItems, totalPrice } = useSelector((state) => state.addToCartData);
  console.log("Redux cart:", items, totalPrice);
  // total discount
  const totalDiscount = items.map((i) => i?.productId?.originalPrice).reduce((total, item) => total + item, 0);
  console.log("totalDiscount", totalDiscount);

  // get user details from store
  const { user } = useSelector((state) => state.auth);
  console.log("Redux user:", user);




  // inside CartPage...

  // REMOVING broken/redundant handlers since they are moved to CartItem
  // and handleRemove was using undefined setCartData.

  //handlePlaceOrder
  const handlePlaceOrder = () => {
    if (user) {
      navigate('/paymentPage')
      setOpenAddressModal(true);
      alert("Complete Payment to place order");
    } else {
      navigate("/login");
    }
  };


  return (
    <div className="container mx-auto p-6 flex flex-col lg:flex-row gap-6">

      {/* Cart Items */}
      <div className="flex-1 flex flex-col gap-4">
        {items.map((item) => (
          <CartItem key={item?.productId?._id || item.id} item={item} />
        ))}
      </div>

      {/* Price Details */}
      <div className="w-full lg:w-1/3 p-4 border rounded-md bg-white">

        <div className="p-4 -mx-4.5 border rounded-md bg-white mb-5 -mt-10">

          <div>
            <div className="flex items-center justify-between">
              <p className="text-red-600 font-semibold text-[14px]">Delivery Address:</p>
              <div className="flex items-center">
                <button onClick={() => setOpenAddressModal(true)} className="w-auto bg-red-700 text-white p-1 pr-4 text-[10px] rounded font-semibold hover:bg-green-800" >Location </button>
                <MdLocationOn className="-ml-4 text-white" />
              </div>

            </div>
            <p>DLE Industrial Area, Moti Nagar, New Delhi</p>
          </div>


        </div>
        <h2 className="font-semibold text-lg mb-4">PRICE DETAILS</h2>
        <div className="flex justify-between mb-2">
          <span>Total Payable ({totalItems} items)</span>
          <span>₹{totalPrice + 0}</span>
        </div>
        <div className="flex justify-between mb-2 text-green-600">
          <span>Total Discount</span>
          <span>− ₹{totalDiscount}</span>
        </div>
        <div className="flex justify-between mb-2">
          <span>Coupons for you</span>
          <span>− ₹0</span>
        </div>
        <div className="flex justify-between mb-2">
          <span>Protect Promise Fee</span>
          <span>₹0</span>
        </div>
        <hr className="my-2" />
        <div className="flex justify-between font-bold text-lg mb-4">
          <span>Total Amount</span>
          <span>₹{totalPrice}</span>
        </div>
        <p className="text-green-600 text-sm mb-4">
          You will save ₹{"discount: 0"} on this order.
        </p>

        {/* Place Order Button */}
        <button
          onClick={() => handlePlaceOrder()}
          className="w-full bg-green-700 cursor-pointer text-white p-3 rounded font-semibold hover:bg-green-800"
        >
          PLACE ORDER
        </button>
      </div>

      {/* Address Modal */}
      <Modal
        open={openAddressModal}
        onClose={() => setOpenAddressModal(false)}
        aria-labelledby="address-modal"
        aria-describedby="enter-address-for-order"
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "90%",
            maxWidth: "900px",
            bgcolor: "background.paper",
            boxShadow: 24,
            borderRadius: 2,
            outline: "none",
            overflow: "hidden",
          }}
        >
          <AddressModalPage onClose={() => setOpenAddressModal(false)} />
        </Box>
      </Modal>
    </div>
  );
}

export default CartPage;
