

export const getAllProducts = async () => {
    try {
        
    } catch (error) {
        console.log(error.message)
    }
}