// import axios from "axios"
// import toker from '../utils/tokenHelper'


// export const saveAddress = async (data) => {
//     try {
//         axios
//             .post(`${import.meta.env.VITE_BASE_URL}`,
//                 data,
//                 {
//                     headers: {
//                         Authorization: `Bearer: ${token}`
//                     }
//                 }
//             )
//     } catch (error) {
//         console.log(error.message)
//     }
// }