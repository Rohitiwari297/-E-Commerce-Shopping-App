import React from 'react'

function coupon() {
  return (
    <div>coupon</div>
  )
}

export default coupon